<?php
namespace App;
use Illuminate\Database\Eloquent\Model;

class Viewcategory extends Model
{
    
public $timestamps = false;
protected $table = 'category';

}
