<?php

namespace App;
use Illuminate\Database\Eloquent\Model;
class AddProduct extends Model
{
    
    public $timestamps=false;
    
    protected $table='addproduct';
}
