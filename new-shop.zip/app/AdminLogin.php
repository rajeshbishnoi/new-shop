<?php
namespace App;
use Illuminate\Database\Eloquent\Model;

class AdminLogin extends Model
{
    public $timestamps=false;
     public $table='login';
     
}
