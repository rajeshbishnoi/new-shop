<!DOCTYPE html>
<html>
<head>
  <title>Admin | Login</title>
  <link href="<?php echo e(URL::asset('public/css/bootstrap.css')); ?>" rel="stylesheet" type="text/css" media="all"/>
  <link href="<?php echo e(URL::asset('public/css/style.css')); ?>" rel="stylesheet" type="text/css" media="all" />
</head>
<body>
<div>
<nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand" href="#">Admin</a>
    </div>
    <ul class="nav navbar-nav">
      <li class="active"><a href="#">Select Category</a></li>
    </ul>
  </div>
</nav>
</div>
<div class="" style="text-align: center;margin-top:20% ">
<?php echo Form::open(['url' => '/savecategory']); ?>

      
    
      <?php echo Form::label('Select Category','', array('class' => '','placeholder' => '' )); ?><br>

      
      <?php echo Form::select('size', ['L' => 'Large', 'S' => 'Small'], null, ['placeholder' => 'Pick a size...']); ?><br><br>


      <?php echo Form::label('Add Category','', array('class' => '','placeholder' => '' )); ?><br>
      

      <?php echo Form::text('category_name','', array('class' => '','placeholder' => '' )); ?><br><br>


       <?php echo Form::submit('Add','', array('class' => 'btn btn-success','placeholder' => '' )); ?>

    

  <?php echo Form::close(); ?>


</div>
</body>
</html>