<!DOCTYPE html>
<html>
<head>

  <title>Admin | Login</title>
  <link href="<?php echo e(URL::asset('public/css/bootstrap.css')); ?>" rel="stylesheet" type="text/css" media="all"/>
<link href="<?php echo e(URL::asset('public/css/style.css')); ?>" rel="stylesheet" type="text/css" media="all" />
</head>
<body>
<div>
<nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand" href="#">Admin</a>
    </div>
    <ul class="nav navbar-nav">
      <li class="active"><a href="#">AddProduct</a></li>
    </ul>
  </div>
</nav>
</div>
<table class="w3-table" style="width: 60%;margin-left: 20%;font-size: 0.75em">
<div style="text-align: center;">
      <?php echo Form::open(['url' => '/addproduct','enctype'=>'multipart/form-data']); ?>


  <tr>
  <td><?php echo Form::label('Select Category','', array('class' => '','placeholder' => '' )); ?></td>
  
        <td>
          <select name="p_category" id="p_category" onchange="change_category()" >
            <option value=""> Select category </option>


            <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categorys): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($categorys->category_id); ?>"><?php echo e($categorys->category_name); ?></option>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </select>
        </td>  
  </tr>

      <tr><td><?php echo Form::label('Select Sub Category','', array('class' => '','placeholder' => '' )); ?></td>

        <td id="home">
          <select name="sub_category">
            <option value=""> Select Sub fitrst category </option>

            <?php $__currentLoopData = $subcategory; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subcategorys): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($subcategorys->category_name); ?>"><?php echo e($subcategorys->category_name); ?></option>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </select>
        </td>

        <td id="classlist" style="display: none;">
        </td>  
      </tr>
         
<tr>
<td>
      <?php echo Form::label('Product Name','', array('class' => '','placeholder' => '' )); ?><</td>

      <!-- FOR RETRIEVING THE DATA FROM EDIT IN VIEW PRODUCT AND ELSE SIMPLY USING THE PREVIOUS -->
      <td>
      <?php if($get !=""): ?> 

      <?php $__currentLoopData = $get; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gets): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <?php echo Form::text('name',"$gets->addproduct_name", array('class' => '','placeholder' => '' )); ?><br><br>
      
      <?php echo Form::hidden('ID','$gets->addproduct_id'); ?>

      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

      <?php else: ?>
      <?php echo Form::text('name','', array('class' => '','placeholder' => '' )); ?><br><br>
      <?php endif; ?>
      </td>
</tr>

<tr>
  <td>
      <?php echo Form::label('Product size','', array('class' => '','placeholder' => '' )); ?>

  </td>
  <td>
      <?php echo Form::text('size','', array('class' => '','placeholder' => '' )); ?><br><br>
  </td>
</tr>


<tr>
  <td>
      <?php echo Form::label('Product status','', array('class' => '','placeholder' => '' )); ?>

  </td>
  <td>    

      <?php echo Form::text('status','', array('class' => '','placeholder' => '' )); ?><br><br>
  </td>
</tr>  

<tr>
<td>
  <?php echo Form::label('Product Description','',array('class'=>'','placeholder'=>'')); ?>

</td>
<td>
  <?php echo Form::textarea('description','',array('class'=>'','placeholder'=>'')); ?><br><br>
</td>
</tr>
<tr>
  <td>
  <?php echo Form::label('Price','',array('class'=>'','placeholder'=>'')); ?>

  </td>
  <td>
  <?php echo Form::text('price','',array('class'=>'','placeholder'=>'')); ?><br><br>
  </td>
</tr>

<tr>
  <td>
  <?php echo Form::label('Discount Price','',array('class'=>'','placeholder'=>'')); ?>

  </td>
  <td>
  <?php echo Form::text('discountprice','',array('class'=>'','placeholder'=>'')); ?><br><br>
  </td>
</tr>

      <!-- <?php echo Form::label('Product image','', array('class' => '','placeholder' => '' )); ?><br>
      <?php echo Form::file('image'); ?><br> -->
<tr>
  <td>
    <?php echo Form::label('Product Image','',array('class'=>'','placeholder'=> '')); ?>

  </td>
  <td>
    <?php echo Form::file('image'); ?>

  </td>
</tr>
<tr>
  <td>
      <?php echo Form::submit('Add','', array('class' => 'btn btn-success ','placeholder' => '' )); ?>

  </td>
</tr>  
      <?php echo Form::close(); ?>



</div>
</table>
</div>


<script type="text/javascript">
  
  var BASE_URL= "<?php echo e(url('/')); ?>";
</script>

<script type="text/javascript">
  function change_category(){
    var a = $('#p_category').val();
    // alert(a);
    $.ajax({

      url:BASE_URL+"/admin/subcategory/subcategorys/"+a,
      success:function(resonse){
        $('#classlist').show();
        // $('#loadingdiv').show();
        $('#home').hide();
        $('#classlist').html(response);
        // $('#classlist').show();
      }
    });
  }

</script>
<!-- <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script> -->

<script type="text/javascript" src="<?php echo e(URL::asset('public/js/jquery-3.2.0.min.js')); ?>"></script>


<!-- <script type="text/javascript" src="<?php echo e(URL::asset('public/js/bootstrap.js')); ?>"></script> 
<script type="text/javascript" src="<?php echo e(URL::asset('public/js/bootstrap-3.1.1.min.js')); ?>"> --></script>
</body>




</html>