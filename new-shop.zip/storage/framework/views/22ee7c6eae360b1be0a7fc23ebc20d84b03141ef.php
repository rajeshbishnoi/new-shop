
<?php if($function == 'subcategorys'): ?>
<td id="classlist">
	
          <select name="sub_category">
            <option value=""> Select Sub category </option>

            <?php $__currentLoopData = $subcategory; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subcategorys): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            
            <option value="<?php echo e($subcategorys->category_id); ?>"><?php echo e($subcategorys->category_name); ?></option>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </select>
</td>
<?php endif; ?>