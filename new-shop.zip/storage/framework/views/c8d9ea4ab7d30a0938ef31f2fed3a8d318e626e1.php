<!DOCTYPE html>
<html>
<head>
	<title>View Profile</title>
	<link href="<?php echo e(URL::asset('public/css/bootstrap.css')); ?>" rel="stylesheet" type="text/css" media="all"/>
  	<link href="<?php echo e(URL::asset('public/css/style.css')); ?>" rel="stylesheet" type="text/css" media="all" />
</head>
<body>
<div>
<nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand" href="#">Admin</a>
    </div>
    <ul class="nav navbar-nav">
      <li class="active"><a href="#">ViewProfile</a></li>

    </ul>
  </div>
</nav>
<h1 style="text-align: center;"> VIEW PROFILE</h1>
<div style="text-align: center;">
  
  <div class="container" style="margin-top: 30px; ">
<div class="table-responsive">
  <table class="table">
    <thead>
      <tr style="font-size:24px;">
        <th class="col-md-4">Category Id</th>
        <th class="col-md-4">Category Name</th>
        <th class="col-md-4 ">Category Size</th>
      </tr>

      <?php $__currentLoopData = $get_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $get_datas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <tr>
        <th><?php echo e($get_datas -> profile_name); ?></th>
        <th><?php echo e($get_datas -> profile_email); ?></th>
        <th><?php echo e($get_datas -> profile_address); ?></th>
      </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
    
    </thead>
    <tbody>     

    </tbody>
  </table>
</div>
</div>
</div>
</div>
</body>
</html>