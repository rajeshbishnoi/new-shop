<!DOCTYPE html>
<html>
<head>
	<title>View Profile</title>
	<link href="<?php echo e(URL::asset('public/css/bootstrap.css')); ?>" rel="stylesheet" type="text/css" media="all"/>
  	<link href="<?php echo e(URL::asset('public/css/style.css')); ?>" rel="stylesheet" type="text/css" media="all" />
</head>
<body>
<div>
<nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand" href="#">Admin</a>
    </div>
    <ul class="nav navbar-nav">
      <li class="active"><a href="#">ViewProfile</a></li>
<!--       <li><a href="#">Page 1</a></li>
      <li><a href="#">Page 2</a></li>
      <li><a href="#">Page 3</a></li> -->
      <?php $__currentLoopData = $get_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as get_datas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        <?php echo e($get_datas -> profile_name); ?>

      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
  </div>
</nav>
</div>
<div>
	
</div>
</body>
</html>